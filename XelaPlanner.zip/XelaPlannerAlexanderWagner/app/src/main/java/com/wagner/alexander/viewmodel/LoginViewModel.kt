package com.wagner.alexander.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wagner.alexander.data.repository.UserRepository
import com.wagner.alexander.data.state.LoginState
import com.wagner.alexander.utils.SecurityUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LoginViewModel(application: Application) : AndroidViewModel(application) {
    private val userRepository = UserRepository(application)
    private val _uiState = MutableStateFlow(LoginState())
    val uiState: StateFlow<LoginState> = _uiState.asStateFlow()
    
    init {
        // Pre-fill username if user was previously logged in
        val savedUsername = userRepository.getCurrentUsername()
        if (savedUsername.isNotBlank()) {
            _uiState.value = _uiState.value.copy(username = savedUsername)
        }
    }
    
    fun onUsernameChange(username: String) {
        _uiState.value = _uiState.value.copy(
            username = username,
            errorMessage = null
        )
    }
    
    fun onPasswordChange(password: String) {
        _uiState.value = _uiState.value.copy(
            password = password,
            errorMessage = null
        )
    }
    
    fun onLoginClick(onSuccess: () -> Unit) {
        viewModelScope.launch {
            val currentState = _uiState.value
            _uiState.value = currentState.copy(isLoading = true, errorMessage = null)
            
            // Validate input
            val usernameError = SecurityUtils.validateUsername(currentState.username)
            val passwordError = SecurityUtils.validatePassword(currentState.password)
            
            if (usernameError != null) {
                _uiState.value = currentState.copy(
                    isLoading = false,
                    errorMessage = usernameError
                )
                return@launch
            }
            
            if (passwordError != null) {
                _uiState.value = currentState.copy(
                    isLoading = false,
                    errorMessage = passwordError
                )
                return@launch
            }
            
            // Attempt login
            try {
                val user = userRepository.loginUser(currentState.username, currentState.password)
                if (user != null) {
                    _uiState.value = currentState.copy(
                        isLoading = false,
                        isLoggedIn = true
                    )
                    onSuccess()
                } else {
                    _uiState.value = currentState.copy(
                        isLoading = false,
                        errorMessage = "Invalid username or password"
                    )
                }
            } catch (e: Exception) {
                _uiState.value = currentState.copy(
                    isLoading = false,
                    errorMessage = "Login failed. Please try again."
                )
            }
        }
    }
    
    fun onCreateAccountClick(onSuccess: () -> Unit) {
        viewModelScope.launch {
            val currentState = _uiState.value
            _uiState.value = currentState.copy(isLoading = true, errorMessage = null)
            
            // Validate input
            val usernameError = SecurityUtils.validateUsername(currentState.username)
            val passwordError = SecurityUtils.validatePassword(currentState.password)
            
            if (usernameError != null) {
                _uiState.value = currentState.copy(
                    isLoading = false,
                    errorMessage = usernameError
                )
                return@launch
            }
            
            if (passwordError != null) {
                _uiState.value = currentState.copy(
                    isLoading = false,
                    errorMessage = passwordError
                )
                return@launch
            }
            
            // Attempt account creation
            try {
                val user = userRepository.createUser(currentState.username, currentState.password)
                if (user != null) {
                    _uiState.value = currentState.copy(
                        isLoading = false,
                        isLoggedIn = true
                    )
                    onSuccess()
                } else {
                    _uiState.value = currentState.copy(
                        isLoading = false,
                        errorMessage = "Username already exists. Please choose a different one."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = currentState.copy(
                    isLoading = false,
                    errorMessage = "Account creation failed. Please try again."
                )
            }
        }
    }
    
    fun onSkipLoginClick(onSuccess: () -> Unit) {
        userRepository.setSkipLogin(true)
        onSuccess()
    }
}