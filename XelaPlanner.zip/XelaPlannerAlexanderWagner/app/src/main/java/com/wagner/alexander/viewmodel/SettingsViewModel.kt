package com.wagner.alexander.viewmodel

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wagner.alexander.data.repository.SettingsRepository
import com.wagner.alexander.data.repository.UserRepository
import com.wagner.alexander.data.repository.EventRepository
import com.wagner.alexander.data.state.SettingsState
import com.wagner.alexander.notifications.NotificationScheduler
import com.wagner.alexander.notifications.AppNotificationManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val settingsRepository = SettingsRepository(application)
    private val userRepository = UserRepository(application)
    private val eventRepository = EventRepository(application)
    private val notificationScheduler = NotificationScheduler(application)
    private val appNotificationManager = AppNotificationManager(application)
    
    private val _uiState = MutableStateFlow(SettingsState())
    val uiState: StateFlow<SettingsState> = _uiState.asStateFlow()
    
    init {
        loadSettings()
    }
    
    private fun loadSettings() {
        _uiState.value = _uiState.value.copy(
            smsEnabled = settingsRepository.isSmsEnabled(),
            appNotificationsEnabled = settingsRepository.isAppNotificationsEnabled(),
            phoneNumber = settingsRepository.getPhoneNumber(),
            timeFormat24H = settingsRepository.isTimeFormat24H(),
            isLoggedIn = userRepository.isLoggedIn(),
            username = userRepository.getCurrentUsername()
        )
    }
    
    /**
     * Handles SMS toggle - includes permission checking and user guidance
     */
    fun onSmsToggleClick(enabled: Boolean, context: Context) {
        if (enabled) {
            if (checkSmsPermission(context)) {
                if (settingsRepository.hasPhoneNumber()) {
                    enableSms()
                } else {
                    _uiState.value = _uiState.value.copy(showPhoneNumberDialog = true)
                }
            } else {
                _uiState.value = _uiState.value.copy(showPermissionExplanationDialog = true)
            }
        } else {
            disableSms()
        }
    }

    fun handleSmsPermissionResult(isGranted: Boolean) {
        if (isGranted) {
            if (settingsRepository.hasPhoneNumber()) {
                enableSms()
            } else {
                _uiState.value = _uiState.value.copy(showPhoneNumberDialog = true)
            }
        } else {
            _uiState.value = _uiState.value.copy(
                smsEnabled = false,
                errorMessage = "SMS permission was not granted"
            )
            clearMessages()
        }
    }
    
    /**
     * Handles app notification toggle - includes permission checking
     */
    fun onAppNotificationToggleClick(enabled: Boolean, context: Context) {
        if (enabled) {
            // User wants to enable app notifications
            if (appNotificationManager.hasNotificationPermission()) {
                // Permission granted - enable notifications
                enableAppNotifications()
            } else {
                // Need permission - show explanation dialog
                _uiState.value = _uiState.value.copy(showAppNotificationPermissionDialog = true)
            }
        } else {
            // User wants to disable app notifications
            disableAppNotifications()
        }
    }
    
    /**
     * Enables SMS notifications after all requirements are met
     */
    private fun enableSms() {
        settingsRepository.setSmsEnabled(true)
        _uiState.value = _uiState.value.copy(
            smsEnabled = true,
            successMessage = "SMS notifications enabled"
        )
        
        // Schedule notifications for all existing events
        viewModelScope.launch {
            try {
                val userId = if (userRepository.isLoggedIn()) userRepository.getCurrentUserId() else 0L
                eventRepository.getEventsForUser(userId).collect { events ->
                    notificationScheduler.scheduleNotifications(events)
                }
            } catch (e: Exception) {
                // Handle error silently
            }
        }
        
        clearMessages()
    }
    
    /**
     * Disables SMS notifications
     */
    private fun disableSms() {
        settingsRepository.setSmsEnabled(false)
        _uiState.value = _uiState.value.copy(
            smsEnabled = false,
            successMessage = "SMS notifications disabled"
        )
        
        // Cancel all scheduled SMS notifications
        notificationScheduler.cancelAllNotifications()
        
        clearMessages()
    }
    
    /**
     * Enables app notifications after permission is granted
     */
    private fun enableAppNotifications() {
        settingsRepository.setAppNotificationsEnabled(true)
        _uiState.value = _uiState.value.copy(
            appNotificationsEnabled = true,
            successMessage = "App notifications enabled"
        )
        clearMessages()
    }
    
    /**
     * Disables app notifications
     */
    private fun disableAppNotifications() {
        settingsRepository.setAppNotificationsEnabled(false)
        _uiState.value = _uiState.value.copy(
            appNotificationsEnabled = false,
            successMessage = "App notifications disabled"
        )
        
        // Cancel all app notifications
        appNotificationManager.cancelAllNotifications()
        
        clearMessages()
    }
    
    /**
     * Handles phone number submission
     */
    fun onPhoneNumberSubmitted(phoneNumber: String) {
        val validationError = settingsRepository.validatePhoneNumber(phoneNumber)
        if (validationError != null) {
            _uiState.value = _uiState.value.copy(
                errorMessage = validationError,
                showPhoneNumberDialog = false
            )
            clearMessages()
            return
        }
        
        // Save phone number and enable SMS
        settingsRepository.setPhoneNumber(phoneNumber)
        _uiState.value = _uiState.value.copy(
            phoneNumber = settingsRepository.getPhoneNumber(),
            showPhoneNumberDialog = false,
            successMessage = "Phone number saved. In a production app, we would send a verification code."
        )
        
        // Enable SMS now that we have the phone number
        enableSms()
    }
    
    /**
     * Handles time format toggle
     */
    fun onTimeFormatToggle(use24H: Boolean) {
        settingsRepository.setTimeFormat24H(use24H)
        _uiState.value = _uiState.value.copy(
            timeFormat24H = use24H,
            successMessage = "Time format updated to ${if (use24H) "24-hour" else "12-hour"}"
        )
        
        // Reschedule all notifications with new time format
        if (settingsRepository.isSmsEnabled() && settingsRepository.hasPhoneNumber()) {
            viewModelScope.launch {
                try {
                    val userId = if (userRepository.isLoggedIn()) userRepository.getCurrentUserId() else 0L
                    eventRepository.getEventsForUser(userId).collect { events ->
                        notificationScheduler.rescheduleAllNotifications(events)
                    }
                } catch (e: Exception) {
                    // Handle error silently
                }
            }
        }
        
        clearMessages()
    }
    
    /**
     * Handles logout
     */
    fun onLogout() {
        userRepository.logoutUser()
        _uiState.value = _uiState.value.copy(
            isLoggedIn = false,
            username = "",
            successMessage = "Logged out successfully"
        )
        clearMessages()
    }
    
    /**
     * Dismisses dialogs
     */
    fun onDismissPhoneNumberDialog() {
        _uiState.value = _uiState.value.copy(showPhoneNumberDialog = false)
    }
    
    fun onDismissPermissionDialog() {
        _uiState.value = _uiState.value.copy(showPermissionExplanationDialog = false)
    }
    
    fun onDismissAppNotificationPermissionDialog() {
        _uiState.value = _uiState.value.copy(showAppNotificationPermissionDialog = false)
    }
    
    /**
     * Opens app settings for permission management
     */
    fun openAppSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
        }
        context.startActivity(intent)
        _uiState.value = _uiState.value.copy(showPermissionExplanationDialog = false)
    }
    
    /**
     * Checks if SMS permission is granted
     */
    fun checkSmsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * Checks if app notification permission is granted
     */
    fun checkAppNotificationPermission(context: Context): Boolean {
        return appNotificationManager.hasNotificationPermission()
    }
    
    /**
     * Clears success/error messages after a delay
     */
    private fun clearMessages() {
        viewModelScope.launch {
            kotlinx.coroutines.delay(3000)
            _uiState.value = _uiState.value.copy(
                successMessage = null,
                errorMessage = null
            )
        }
    }
    
    /**
     * Gets formatted phone number for display
     */
    fun getFormattedPhoneNumber(): String {
        return if (_uiState.value.phoneNumber.isNotBlank()) {
            settingsRepository.formatPhoneNumber(_uiState.value.phoneNumber)
        } else {
            "Not set"
        }
    }
}
