package com.wagner.alexander.utils

import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Security utilities for password hashing and validation
 */
object SecurityUtils {
    
    /**
     * Generates a random salt for password hashing
     */
    private fun generateSalt(): ByteArray {
        val random = SecureRandom()
        val salt = ByteArray(16)
        random.nextBytes(salt)
        return salt
    }
    
    /**
     * Converts byte array to hex string
     */
    private fun bytesToHex(bytes: ByteArray): String {
        return bytes.joinToString("") { "%02x".format(it) }
    }
    
    /**
     * Converts hex string to byte array
     */
    private fun hexToBytes(hex: String): ByteArray {
        return hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }
    
    /**
     * Hashes a password with salt using SHA-256
     * Returns: "salt:hash" format
     */
    fun hashPassword(password: String): String {
        val salt = generateSalt()
        val digest = MessageDigest.getInstance("SHA-256")
        
        // Combine password and salt
        val passwordBytes = password.toByteArray(Charsets.UTF_8)
        val saltedPassword = salt + passwordBytes
        
        // Hash the salted password
        val hash = digest.digest(saltedPassword)
        
        // Return salt and hash in hex format
        return "${bytesToHex(salt)}:${bytesToHex(hash)}"
    }
    
    /**
     * Verifies a password against a stored hash
     * storedHash should be in format "salt:hash"
     */
    fun verifyPassword(password: String, storedHash: String): Boolean {
        return try {
            val parts = storedHash.split(":")
            if (parts.size != 2) return false
            
            val salt = hexToBytes(parts[0])
            val originalHash = parts[1]
            
            val digest = MessageDigest.getInstance("SHA-256")
            val passwordBytes = password.toByteArray(Charsets.UTF_8)
            val saltedPassword = salt + passwordBytes
            val newHash = digest.digest(saltedPassword)
            
            bytesToHex(newHash) == originalHash
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * Validates password strength
     * Returns null if valid, error message if invalid
     */
    fun validatePassword(password: String): String? {
        return when {
            password.length < 6 -> "Password must be at least 6 characters"
            password.isBlank() -> "Password cannot be empty"
            else -> null
        }
    }
    
    /**
     * Validates username format
     * Returns null if valid, error message if invalid
     */
    fun validateUsername(username: String): String? {
        return when {
            username.length < 3 -> "Username must be at least 3 characters"
            username.length > 20 -> "Username must be less than 20 characters"
            !username.matches(Regex("^[a-zA-Z0-9_]+$")) -> "Username can only contain letters, numbers, and underscores"
            username.isBlank() -> "Username cannot be empty"
            else -> null
        }
    }
}
