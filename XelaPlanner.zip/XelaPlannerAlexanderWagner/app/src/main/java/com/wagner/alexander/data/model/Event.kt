package com.wagner.alexander.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDateTime

@Entity(tableName = "events")
data class Event(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val description: String = "",
    val eventDate: LocalDateTime,
    val category: EventCategory = EventCategory.PERSONAL,
    val userId: Long = 0L, // Associate events with users (0 = guest/unregistered user)
    val createdAt: Long = System.currentTimeMillis()
)

enum class EventCategory {
    PERSONAL, WORK, STUDY, FAMILY, HEALTH
}