package com.wagner.alexander.viewmodel

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wagner.alexander.data.model.Event
import com.wagner.alexander.data.repository.EventRepository
import com.wagner.alexander.data.repository.UserRepository
import com.wagner.alexander.data.repository.SettingsRepository
import com.wagner.alexander.data.state.DashboardState
import com.wagner.alexander.notifications.NotificationScheduler
import com.wagner.alexander.notifications.AppNotificationManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime

class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val userRepository = UserRepository(application)
    private val eventRepository = EventRepository(application)
    private val settingsRepository = SettingsRepository(application)
    private val notificationScheduler = NotificationScheduler(application)
    private val appNotificationManager = AppNotificationManager(application)
    
    private val _uiState = MutableStateFlow(DashboardState())
    val uiState: StateFlow<DashboardState> = _uiState.asStateFlow()
    
    private val currentUserIdValue: Long
        get() = if (userRepository.isLoggedIn()) userRepository.getCurrentUserId() else 0L
    
    init {
        loadEvents()
    }
    
    private fun loadEvents() {
        viewModelScope.launch {
            eventRepository.getEventsForUser(currentUserIdValue).collect { events ->
                val now = LocalDateTime.now()
                val upcomingEvents = events.filter { it.eventDate.isAfter(now) }
                    .sortedBy { it.eventDate }
                val pastEvents = events.filter { it.eventDate.isBefore(now) || it.eventDate.isEqual(now) }
                    .sortedByDescending { it.eventDate }
                
                _uiState.value = _uiState.value.copy(
                    events = events,
                    upcomingEvents = upcomingEvents,
                    pastEvents = pastEvents,
                    isLoading = false
                )
            }
        }
    }
    
    fun onDateSelected(date: LocalDate) {
        _uiState.value = _uiState.value.copy(selectedDate = date)
    }
    
    fun onClearDateFilter() {
        _uiState.value = _uiState.value.copy(selectedDate = null)
    }
    
    fun onAddEventForDate(date: LocalDate) {
        _uiState.value = _uiState.value.copy(
            showAddEventSheet = true,
            preselectedDate = date
        )
    }
    
    fun onAddEventClick() {
        _uiState.value = _uiState.value.copy(showAddEventSheet = true)
    }
    
    fun onEditEvent(event: Event) {
        _uiState.value = _uiState.value.copy(
            eventToEdit = event,
            showAddEventSheet = true
        )
    }
    
    fun onDeleteEvent(eventId: Long) {
        viewModelScope.launch {
            try {
                // Cancel any scheduled notifications first
                notificationScheduler.cancelNotification(eventId)
                appNotificationManager.cancelNotification(eventId)
                // Delete the event from database
                eventRepository.deleteEventById(eventId)
                // Show success message
                _uiState.value = _uiState.value.copy(
                    successMessage = "Event deleted successfully"
                )
                clearMessages()
            } catch (e: Exception) {
                // Show error message to user
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Failed to delete event. Please try again."
                )
                clearMessages()
            }
        }
    }
    
    fun onLongPressDelete(event: Event) {
        _uiState.value = _uiState.value.copy(
            showDeleteConfirmationDialog = true,
            eventToDelete = event
        )
    }
    
    fun onConfirmDelete() {
        _uiState.value.eventToDelete?.let { event ->
            onDeleteEvent(event.id)
        }
        _uiState.value = _uiState.value.copy(
            showDeleteConfirmationDialog = false,
            eventToDelete = null
        )
    }
    
    fun onDismissDeleteDialog() {
        _uiState.value = _uiState.value.copy(
            showDeleteConfirmationDialog = false,
            eventToDelete = null
        )
    }
    
    fun onDismissBottomSheet() {
        _uiState.value = _uiState.value.copy(
            showAddEventSheet = false,
            eventToEdit = null,
            preselectedDate = null
        )
    }
    
    fun onSaveEvent(event: Event) {
        viewModelScope.launch {
            try {
                // Validate event data
                val validationError = eventRepository.validateEvent(event)
                if (validationError != null) {
                    _uiState.value = _uiState.value.copy(
                        errorMessage = validationError
                    )
                    clearMessages()
                    return@launch
                }
                
                // Add user ID to event
                val eventWithUserId = event.copy(userId = currentUserIdValue)
                
                val isNewEvent = event.id == 0L
                val savedEvent = if (isNewEvent) {
                    val newEvent = eventRepository.createEvent(eventWithUserId)
                    // Schedule SMS notification if enabled
                    notificationScheduler.scheduleNotification(newEvent)
                    // Check for permission setup for new users
                    checkPermissionsAfterSave(newEvent)
                    newEvent
                } else {
                    eventRepository.updateEvent(eventWithUserId)
                    // Reschedule SMS notification with updated details
                    notificationScheduler.rescheduleNotification(eventWithUserId)
                    eventWithUserId
                }
                
                // Close bottom sheet and show success message
                _uiState.value = _uiState.value.copy(
                    showAddEventSheet = false,
                    eventToEdit = null,
                    preselectedDate = null,
                    successMessage = if (isNewEvent) "Event created successfully" else "Event updated successfully"
                )
                clearMessages()
                
            } catch (e: Exception) {
                // Show error message to user
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Failed to save event. Please try again."
                )
                clearMessages()
            }
        }
    }
    
    private fun checkPermissionsAfterSave(event: Event) {
        // New onboarding: show combined reminder setup dialog on first event creation only
        if (!settingsRepository.hasReminderSetupShown()) {
            _uiState.value = _uiState.value.copy(
                showReminderSetupDialog = true,
                eventForPermissionCheck = event
            )
        }
    }

    fun onReminderSetupClose() {
        settingsRepository.setReminderSetupShown(true)
        _uiState.value = _uiState.value.copy(
            showReminderSetupDialog = false,
            eventForPermissionCheck = null
        )
    }

    /**
     * Called when user chose both push and SMS in the reminder setup; we defer SMS until after push permission result.
     */
    fun markPendingSmsAfterPush() {
        _uiState.value = _uiState.value.copy(pendingEnableSmsAfterPush = true)
    }

    /**
     * Starts the SMS setup permission flow by showing the SMS permission dialog.
     */
    fun startSmsSetupFlow() {
        _uiState.value = _uiState.value.copy(
            showSmsPermissionDialog = true
        )
    }
    
    fun onSmsPermissionDialogDismiss() {
        _uiState.value = _uiState.value.copy(
            showSmsPermissionDialog = false,
            eventForPermissionCheck = null
        )
    }
    
    /**
     * Called when SMS permission is granted - starts the phone number setup flow
     */
    fun onSmsPermissionGranted() {
        if (!settingsRepository.hasPhoneNumber()) {
            // No phone number saved - show phone number dialog
            _uiState.value = _uiState.value.copy(
                showSmsPermissionDialog = false,
                showPhoneNumberDialog = true
            )
        } else {
            // Phone number already exists - just enable SMS
            enableSmsNotifications()
        }
    }
    
    /**
     * Called when user submits phone number
     */
    fun onPhoneNumberSubmitted(phoneNumber: String) {
        val validationError = settingsRepository.validatePhoneNumber(phoneNumber)
        if (validationError != null) {
            _uiState.value = _uiState.value.copy(
                errorMessage = validationError
            )
            clearMessages()
            return
        }
        
        // Save phone number
        settingsRepository.setPhoneNumber(phoneNumber)
        
        // Show phone number saved dialog
        _uiState.value = _uiState.value.copy(
            showPhoneNumberDialog = false,
            showPhoneNumberSavedDialog = true
        )
    }
    
    /**
     * Called when phone number saved dialog is dismissed - enables SMS
     */
    fun onPhoneNumberSavedDialogDismiss() {
        _uiState.value = _uiState.value.copy(
            showPhoneNumberSavedDialog = false
        )
        // Enable SMS notifications now
        enableSmsNotifications()
    }
    
    /**
     * Called when phone number dialog is dismissed without saving
     */
    fun onPhoneNumberDialogDismiss() {
        _uiState.value = _uiState.value.copy(
            showPhoneNumberDialog = false
        )
    }
    
    /**
     * Enables SMS notifications and schedules notifications for existing events
     */
    private fun enableSmsNotifications() {
        settingsRepository.setSmsEnabled(true)
        
        // Schedule notifications for all existing events
        viewModelScope.launch {
            try {
                val events = _uiState.value.events
                notificationScheduler.scheduleNotifications(events)
                _uiState.value = _uiState.value.copy(
                    successMessage = "SMS notifications enabled successfully"
                )
                clearMessages()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Failed to enable SMS notifications"
                )
                clearMessages()
            }
        }
    }
    
    fun checkSmsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context, 
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    fun checkAppNotificationPermission(context: Context): Boolean {
        return appNotificationManager.hasNotificationPermission()
    }
    
    fun onAppNotificationPermissionGranted() {
        onAppNotificationPermissionResult(true)
    }

    fun onAppNotificationPermissionResult(isGranted: Boolean) {
        val shouldProceedWithSms = _uiState.value.pendingEnableSmsAfterPush
        if (isGranted) {
            settingsRepository.setAppNotificationsEnabled(true)
            _uiState.value = _uiState.value.copy(
                showAppNotificationPermissionDialog = false,
                successMessage = "App notifications enabled successfully",
                pendingEnableSmsAfterPush = false
            )
            clearMessages()
        } else {
            // Ensure dialog is closed if shown; do not enable notifications
            _uiState.value = _uiState.value.copy(
                showAppNotificationPermissionDialog = false,
                pendingEnableSmsAfterPush = false
            )
        }
        if (shouldProceedWithSms) {
            startSmsSetupFlow()
        }
    }
    
    fun onAppNotificationPermissionDialogDismiss() {
        _uiState.value = _uiState.value.copy(
            showAppNotificationPermissionDialog = false,
            eventForPermissionCheck = null
        )
    }
    
    fun getCurrentUserId(): Long = currentUserIdValue
    
    fun isLoggedIn(): Boolean = userRepository.isLoggedIn()
    
    /**
     * Clears success/error messages after a delay
     */
    private fun clearMessages() {
        viewModelScope.launch {
            kotlinx.coroutines.delay(3000)
            _uiState.value = _uiState.value.copy(
                successMessage = null,
                errorMessage = null
            )
        }
    }
}