package com.wagner.alexander

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.wagner.alexander.data.repository.UserRepository
import com.wagner.alexander.ui.screens.DashboardScreen
import com.wagner.alexander.ui.screens.LoginScreen
import com.wagner.alexander.ui.screens.SettingsScreen
import com.wagner.alexander.ui.theme.XelaPlannerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            XelaPlannerTheme {
                XelaPlannerApp()
            }
        }
    }
}

@Composable
fun XelaPlannerApp() {
    val navController = rememberNavController()
    val userRepository = remember { UserRepository(navController.context) }
    
    // Determine starting destination based on user session
    val startDestination = remember {
        when {
            userRepository.isLoggedIn() -> "dashboard"
            userRepository.shouldSkipLogin() -> "dashboard"
            else -> "login"
        }
    }
    
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable("login") {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate("dashboard") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }
        
        composable("dashboard") {
            DashboardScreen(
                onNavigateToSettings = {
                    navController.navigate("settings")
                }
            )
        }
        
        composable("settings") {
            SettingsScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onLogout = {
                    navController.navigate("login") {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }
    }
}