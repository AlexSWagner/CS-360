package com.wagner.alexander.data.state

data class SettingsState(
    val smsEnabled: Boolean = false,
    val appNotificationsEnabled: Boolean = false,
    val phoneNumber: String = "",
    val timeFormat24H: Boolean = false,
    val isLoggedIn: Boolean = false,
    val username: String = "",
    val showPhoneNumberDialog: Boolean = false,
    val showPermissionExplanationDialog: Boolean = false,
    val showAppNotificationPermissionDialog: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null
)
