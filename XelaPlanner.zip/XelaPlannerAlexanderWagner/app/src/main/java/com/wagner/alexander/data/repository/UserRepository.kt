package com.wagner.alexander.data.repository

import android.content.Context
import com.wagner.alexander.data.database.XelaPlannerDatabase
import com.wagner.alexander.data.model.User
import com.wagner.alexander.utils.SecurityUtils
import com.wagner.alexander.utils.SecureStorage

/**
 * Repository for managing user-related operations
 * Coordinates between database, secure storage, and authentication logic
 */
class UserRepository(context: Context) {
    
    private val database = XelaPlannerDatabase.getDatabase(context)
    private val userDao = database.userDao()
    private val secureStorage = SecureStorage(context)
    
    /**
     * Attempts to log in a user with username and password
     * Returns the User if successful, null if failed
     * 
     * @param username The username to authenticate
     * @param password The plain text password to verify
     * @return User object if authentication successful, null otherwise
     */
    suspend fun loginUser(username: String, password: String): User? {
        return try {
            // Validate input format
            SecurityUtils.validateUsername(username)?.let { return null }
            SecurityUtils.validatePassword(password)?.let { return null }
            
            // Retrieve user from database
            val user = userDao.getUserByUsername(username) ?: return null
            
            // Verify password hash
            if (!SecurityUtils.verifyPassword(password, user.passwordHash)) {
                return null
            }
            
            // Save session in secure storage
            secureStorage.setUserSession(user.id, user.username)
            
            user
        } catch (e: Exception) {
            // Log error in production environment
            null
        }
    }
    
    /**
     * Creates a new user account with secure password hashing
     * Returns the created User if successful, null if username already exists
     * 
     * @param username The desired username (must be unique)
     * @param password The plain text password to hash and store
     * @param email Optional email address
     * @return User object if creation successful, null if username exists or validation fails
     */
    suspend fun createUser(username: String, password: String, email: String = ""): User? {
        return try {
            // Validate input format and strength
            SecurityUtils.validateUsername(username)?.let { return null }
            SecurityUtils.validatePassword(password)?.let { return null }
            
            // Ensure username is unique
            if (userDao.isUsernameExists(username) > 0) {
                return null
            }
            
            // Generate secure password hash with salt
            val passwordHash = SecurityUtils.hashPassword(password)
            val user = User(
                username = username,
                passwordHash = passwordHash,
                email = email
            )
            
            // Persist user to database
            val userId = userDao.insertUser(user)
            val createdUser = user.copy(id = userId)
            
            // Initialize user session
            secureStorage.setUserSession(userId, username)
            
            createdUser
        } catch (e: Exception) {
            // Log error in production environment
            null
        }
    }
    
    /**
     * Logs out the current user
     */
    fun logoutUser() {
        secureStorage.clearUserSession()
    }
    
    /**
     * Checks if user is currently logged in
     */
    fun isLoggedIn(): Boolean = secureStorage.isLoggedIn()
    
    /**
     * Gets the current logged-in user ID
     */
    fun getCurrentUserId(): Long = secureStorage.getUserId()
    
    /**
     * Gets the current logged-in username
     */
    fun getCurrentUsername(): String = secureStorage.getUsername()
    
    /**
     * Gets user by ID from database
     */
    suspend fun getUserById(userId: Long): User? = userDao.getUserById(userId)
    
    /**
     * Updates user information
     */
    suspend fun updateUser(user: User) = userDao.updateUser(user)
    
    /**
     * Deletes a user account (also clears session if it's the current user)
     */
    suspend fun deleteUser(user: User) {
        if (user.id == getCurrentUserId()) {
            logoutUser()
        }
        userDao.deleteUser(user)
    }
    
    /**
     * Sets skip login preference
     */
    fun setSkipLogin(skip: Boolean) {
        secureStorage.setSkipLogin(skip)
    }
    
    /**
     * Checks if user prefers to skip login
     */
    fun shouldSkipLogin(): Boolean = secureStorage.shouldSkipLogin()
}
