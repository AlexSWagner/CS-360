package com.wagner.alexander.notifications

import android.content.Context
import androidx.work.*
import com.wagner.alexander.data.model.Event
import com.wagner.alexander.data.repository.SettingsRepository
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

/**
 * Handles scheduling and canceling SMS notifications for events
 * Integrates with WorkManager for reliable notification delivery
 * Also coordinates with AppNotificationManager for immediate notifications
 */
class NotificationScheduler(private val context: Context) {
    
    private val workManager = WorkManager.getInstance(context)
    private val settingsRepository = SettingsRepository(context)
    private val appNotificationManager = AppNotificationManager(context)
    
    companion object {
        private const val WORK_TAG_PREFIX = "sms_notification_"
        private const val NOTIFICATION_ADVANCE_MINUTES = 0L // Send at event time
    }
    
    /**
     * Schedules an SMS notification for an event
     * Only schedules if SMS is enabled and phone number is available
     * Also shows immediate app notification if enabled and event is starting soon
     */
    fun scheduleNotification(event: Event) {
        // Handle immediate app notification if event is starting within 15 minutes
        val now = LocalDateTime.now()
        val minutesUntilEvent = java.time.Duration.between(now, event.eventDate).toMinutes()
        
        if (settingsRepository.isAppNotificationsEnabled() && 
            minutesUntilEvent in 0..15 && 
            event.eventDate.isAfter(now)) {
            // Show immediate app notification for events starting soon
            appNotificationManager.showEventNotification(event)
        }
        
        // Check if SMS notifications are enabled globally
        if (!settingsRepository.isSmsEnabled()) {
            return
        }
        
        // Check if phone number is available
        if (!settingsRepository.hasPhoneNumber()) {
            return
        }
        
        // Calculate notification time (at event time)
        val notificationTime = event.eventDate.minusMinutes(NOTIFICATION_ADVANCE_MINUTES)
        val currentTime = LocalDateTime.now()
        
        // Don't schedule notifications for past events
        if (notificationTime.isBefore(currentTime)) {
            return
        }
        
        // Calculate delay
        val delayMinutes = java.time.Duration.between(currentTime, notificationTime).toMinutes()
        
        // Format event time for display
        val formatter = if (settingsRepository.isTimeFormat24H()) {
            DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm")
        } else {
            DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm a")
        }
        val formattedTime = event.eventDate.format(formatter)
        
        // Create work request
        val workRequest = OneTimeWorkRequestBuilder<SmsNotificationWorker>()
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .setInputData(
                workDataOf(
                    SmsNotificationWorker.KEY_EVENT_ID to event.id,
                    SmsNotificationWorker.KEY_EVENT_TITLE to event.title,
                    SmsNotificationWorker.KEY_EVENT_TIME to formattedTime
                )
            )
            .addTag(getWorkTag(event.id))
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                    .build()
            )
            .build()
        
        // Schedule the work
        workManager.enqueueUniqueWork(
            getWorkName(event.id),
            ExistingWorkPolicy.REPLACE,
            workRequest
        )
    }
    
    /**
     * Cancels a scheduled notification for an event
     * Cancels both SMS and app notifications
     */
    fun cancelNotification(eventId: Long) {
        workManager.cancelUniqueWork(getWorkName(eventId))
        appNotificationManager.cancelNotification(eventId)
    }
    
    /**
     * Cancels all scheduled notifications
     * Useful when SMS is disabled globally
     * Also cancels all app notifications
     */
    fun cancelAllNotifications() {
        workManager.cancelAllWorkByTag(WORK_TAG_PREFIX)
        appNotificationManager.cancelAllNotifications()
    }
    
    /**
     * Reschedules notification for an updated event
     */
    fun rescheduleNotification(event: Event) {
        cancelNotification(event.id)
        scheduleNotification(event)
    }
    
    /**
     * Schedules notifications for a list of events
     * Useful for bulk operations
     */
    fun scheduleNotifications(events: List<Event>) {
        events.forEach { event ->
            scheduleNotification(event)
        }
    }
    
    /**
     * Cancels notifications for a list of event IDs
     */
    fun cancelNotifications(eventIds: List<Long>) {
        eventIds.forEach { eventId ->
            cancelNotification(eventId)
        }
    }
    
    /**
     * Reschedules all notifications for events
     * Useful when settings change (like time format or phone number)
     */
    fun rescheduleAllNotifications(events: List<Event>) {
        cancelAllNotifications()
        if (settingsRepository.isSmsEnabled() && settingsRepository.hasPhoneNumber()) {
            scheduleNotifications(events)
        }
    }
    
    private fun getWorkName(eventId: Long): String {
        return "${WORK_TAG_PREFIX}${eventId}"
    }
    
    private fun getWorkTag(eventId: Long): String {
        return "${WORK_TAG_PREFIX}${eventId}"
    }
}
