package com.wagner.alexander.data.database

import androidx.room.*
import com.wagner.alexander.data.model.Event
import kotlinx.coroutines.flow.Flow
import java.time.LocalDateTime

/**
 * Data Access Object for Event operations
 */
@Dao
interface EventDao {
    
    @Query("SELECT * FROM events WHERE userId = :userId OR userId = 0 ORDER BY eventDate ASC")
    fun getEventsForUser(userId: Long): Flow<List<Event>>
    
    @Query("SELECT * FROM events WHERE userId = 0 ORDER BY eventDate ASC")
    fun getGuestEvents(): Flow<List<Event>>
    
    @Query("SELECT * FROM events WHERE id = :eventId LIMIT 1")
    suspend fun getEventById(eventId: Long): Event?
    
    @Query("SELECT * FROM events WHERE (userId = :userId OR userId = 0) AND DATE(eventDate) = DATE(:date) ORDER BY eventDate ASC")
    suspend fun getEventsForDate(userId: Long, date: LocalDateTime): List<Event>
    
    @Query("SELECT * FROM events WHERE (userId = :userId OR userId = 0) AND eventDate >= :startDate AND eventDate <= :endDate ORDER BY eventDate ASC")
    suspend fun getEventsInRange(userId: Long, startDate: LocalDateTime, endDate: LocalDateTime): List<Event>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: Event): Long
    
    @Update
    suspend fun updateEvent(event: Event)
    
    @Delete
    suspend fun deleteEvent(event: Event)
    
    @Query("DELETE FROM events WHERE id = :eventId")
    suspend fun deleteEventById(eventId: Long)
    
    @Query("DELETE FROM events WHERE userId = :userId")
    suspend fun deleteEventsForUser(userId: Long)
}
