package com.wagner.alexander.utils

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * Utility object for consistent time formatting across the app
 * Handles 12-hour vs 24-hour format based on user preferences
 */
object TimeFormatUtils {
    
    /**
     * Formats a LocalDateTime based on user's time format preference
     * 
     * @param dateTime The LocalDateTime to format
     * @param use24HourFormat Whether to use 24-hour format
     * @param includeDate Whether to include the date
     * @return Formatted time string
     */
    fun formatDateTime(
        dateTime: LocalDateTime, 
        use24HourFormat: Boolean, 
        includeDate: Boolean = true
    ): String {
        val pattern = when {
            includeDate && use24HourFormat -> "MMM dd, yyyy HH:mm"
            includeDate && !use24HourFormat -> "MMM dd, yyyy hh:mm a"
            !includeDate && use24HourFormat -> "HH:mm"
            else -> "hh:mm a"
        }
        return dateTime.format(DateTimeFormatter.ofPattern(pattern))
    }
    
    /**
     * Formats just the time portion
     */
    fun formatTime(dateTime: LocalDateTime, use24HourFormat: Boolean): String {
        return formatDateTime(dateTime, use24HourFormat, includeDate = false)
    }
    
    /**
     * Formats just the date portion
     */
    fun formatDate(dateTime: LocalDateTime): String {
        return dateTime.format(DateTimeFormatter.ofPattern("MMM dd, yyyy"))
    }
    
    /**
     * Gets the appropriate DateTimeFormatter for input fields
     */
    fun getInputFormatter(use24HourFormat: Boolean): DateTimeFormatter {
        return if (use24HourFormat) {
            DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm")
        } else {
            DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm a")
        }
    }

    /**
     * Formats a LocalDateTime as a verbose, human-readable string.
     * Examples:
     * - 12h: "Thursday, August 21, 2025 at 3:00 PM"
     * - 24h: "Thursday, August 21, 2025 at 15:00"
     */
    fun formatVerboseDateTime(dateTime: LocalDateTime, use24HourFormat: Boolean): String {
        val pattern = if (use24HourFormat) {
            "EEEE, MMMM d, yyyy 'at' HH:mm"
        } else {
            "EEEE, MMMM d, yyyy 'at' h:mm a"
        }
        return dateTime.format(DateTimeFormatter.ofPattern(pattern))
    }
}
