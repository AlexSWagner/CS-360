package com.wagner.alexander.data.repository

import android.content.Context
import com.wagner.alexander.utils.SecureStorage

/**
 * Repository for managing app settings and preferences
 * Handles SMS preferences, time format, and other user settings
 */
class SettingsRepository(context: Context) {
    
    private val secureStorage = SecureStorage(context)
    
    /**
     * SMS Notification Settings
     */
    fun setSmsEnabled(enabled: Boolean) {
        secureStorage.setSmsEnabled(enabled)
    }
    
    fun isSmsEnabled(): Boolean = secureStorage.isSmsEnabled()
    
    /**
     * App Notification Settings
     */
    fun setAppNotificationsEnabled(enabled: Boolean) {
        secureStorage.setAppNotificationsEnabled(enabled)
    }
    
    fun isAppNotificationsEnabled(): Boolean = secureStorage.isAppNotificationsEnabled()
    
    fun setPhoneNumber(phoneNumber: String) {
        // Basic phone number validation
        val cleanedNumber = phoneNumber.trim().replace(Regex("[^+\\d]"), "")
        secureStorage.setPhoneNumber(cleanedNumber)
    }
    
    fun getPhoneNumber(): String = secureStorage.getPhoneNumber()
    
    fun hasPhoneNumber(): Boolean = secureStorage.hasPhoneNumber()
    
    /**
     * Time Format Settings
     */
    fun setTimeFormat24H(use24H: Boolean) {
        secureStorage.setTimeFormat24H(use24H)
    }
    
    fun isTimeFormat24H(): Boolean = secureStorage.isTimeFormat24H()
    
    /**
     * Reminder setup onboarding state
     */
    fun setReminderSetupShown(shown: Boolean) {
        secureStorage.setReminderSetupShown(shown)
    }
    
    fun hasReminderSetupShown(): Boolean = secureStorage.hasReminderSetupShown()
    
    /**
     * Validates phone number format
     * Returns null if valid, error message if invalid
     */
    fun validatePhoneNumber(phoneNumber: String): String? {
        val raw = phoneNumber.trim()
        if (raw.isEmpty()) return "Phone number cannot be empty"
        // Disallow letters explicitly
        if (Regex("[A-Za-z]").containsMatchIn(raw)) return "Phone number should not contain letters"
        // Allow only digits, spaces, parentheses, hyphens and optional leading +
        if (Regex("[^\\d+()\\-\\s]").containsMatchIn(raw)) return "Phone number contains invalid characters"

        val cleaned = raw.replace(Regex("[^+\\d]"), "")
        return when {
            cleaned.length < 10 -> "Phone number is too short"
            cleaned.length > 15 -> "Phone number is too long"
            !cleaned.matches(Regex("^\\+?[1-9]\\d{9,14}$")) -> "Invalid phone number format"
            else -> null
        }
    }
    
    /**
     * Formats phone number for display
     * Basic formatting for common formats
     */
    fun formatPhoneNumber(phoneNumber: String): String {
        val cleaned = phoneNumber.replace(Regex("[^+\\d]"), "")
        return when {
            cleaned.length == 10 -> {
                // US format: (123) 456-7890
                "(${cleaned.substring(0, 3)}) ${cleaned.substring(3, 6)}-${cleaned.substring(6)}"
            }
            cleaned.length == 11 && cleaned.startsWith("1") -> {
                // US format with country code: +1 (123) 456-7890
                "+1 (${cleaned.substring(1, 4)}) ${cleaned.substring(4, 7)}-${cleaned.substring(7)}"
            }
            cleaned.startsWith("+") -> {
                // International format: keep as is but add spaces
                cleaned.chunked(4).joinToString(" ")
            }
            else -> cleaned
        }
    }
}
