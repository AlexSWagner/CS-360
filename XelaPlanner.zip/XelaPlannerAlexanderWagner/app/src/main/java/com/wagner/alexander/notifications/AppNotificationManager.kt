package com.wagner.alexander.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.wagner.alexander.MainActivity
import com.wagner.alexander.R
import com.wagner.alexander.data.model.Event
import com.wagner.alexander.utils.TimeFormatUtils
import com.wagner.alexander.data.repository.SettingsRepository

/**
 * Manages app notifications for event reminders
 */
class AppNotificationManager(private val context: Context) {
    
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    
    companion object {
        private const val CHANNEL_ID = "event_reminders"
        private const val CHANNEL_NAME = "Event Reminders"
        private const val CHANNEL_DESCRIPTION = "Notifications for upcoming events"
    }
    
    init {
        createNotificationChannel()
    }
    
    /**
     * Creates the notification channel for event reminders
     */
    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            CHANNEL_NAME,
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = CHANNEL_DESCRIPTION
            enableVibration(true)
            setShowBadge(true)
        }
        
        notificationManager.createNotificationChannel(channel)
    }
    
    /**
     * Shows a notification for an upcoming event
     */
    fun showEventNotification(event: Event) {
        if (!hasNotificationPermission()) {
            return
        }
        
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        
        val pendingIntent = PendingIntent.getActivity(
            context,
            event.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val settingsRepository = SettingsRepository(context)
        val use24Hour = settingsRepository.isTimeFormat24H()
        val formattedTime = TimeFormatUtils.formatDateTime(
            event.eventDate, 
            use24HourFormat = use24Hour,
            includeDate = false
        )
        
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground) // You might want to create a specific icon
            .setContentTitle("Upcoming Event: ${event.title}")
            .setContentText("Starting at $formattedTime")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("${event.title}\n$formattedTime\n${event.description}")
            )
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build()
        
        notificationManager.notify(event.id.toInt(), notification)
    }
    
    /**
     * Cancels a specific event notification
     */
    fun cancelNotification(eventId: Long) {
        notificationManager.cancel(eventId.toInt())
    }
    
    /**
     * Cancels all notifications
     */
    fun cancelAllNotifications() {
        notificationManager.cancelAll()
    }
    
    /**
     * Checks if the app has notification permission
     */
    fun hasNotificationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }
}