package com.wagner.alexander.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Secure storage manager using EncryptedSharedPreferences
 * Handles user session data and app preferences securely
 */
class SecureStorage(context: Context) {
    
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()
    
    private val sharedPreferences: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "xela_planner_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    
    companion object {
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USERNAME = "username"
        private const val KEY_SMS_ENABLED = "sms_enabled"
        private const val KEY_APP_NOTIFICATIONS_ENABLED = "app_notifications_enabled"
        private const val KEY_PHONE_NUMBER = "phone_number"
        private const val KEY_TIME_FORMAT_24H = "time_format_24h"
        private const val KEY_SKIP_LOGIN = "skip_login"
        private const val KEY_REMINDER_SETUP_SHOWN = "reminder_setup_shown"
    }
    
    // User Session Management
    fun setUserSession(userId: Long, username: String) {
        sharedPreferences.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putLong(KEY_USER_ID, userId)
            .putString(KEY_USERNAME, username)
            .apply()
    }
    
    fun clearUserSession() {
        sharedPreferences.edit()
            .putBoolean(KEY_IS_LOGGED_IN, false)
            .remove(KEY_USER_ID)
            .remove(KEY_USERNAME)
            .apply()
    }
    
    fun isLoggedIn(): Boolean = sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false)
    
    fun getUserId(): Long = sharedPreferences.getLong(KEY_USER_ID, 0L)
    
    fun getUsername(): String = sharedPreferences.getString(KEY_USERNAME, "") ?: ""
    
    // App Preferences
    fun setSmsEnabled(enabled: Boolean) {
        sharedPreferences.edit()
            .putBoolean(KEY_SMS_ENABLED, enabled)
            .apply()
    }
    
    fun isSmsEnabled(): Boolean = sharedPreferences.getBoolean(KEY_SMS_ENABLED, false)
    
    fun setAppNotificationsEnabled(enabled: Boolean) {
        sharedPreferences.edit()
            .putBoolean(KEY_APP_NOTIFICATIONS_ENABLED, enabled)
            .apply()
    }
    
    fun isAppNotificationsEnabled(): Boolean = sharedPreferences.getBoolean(KEY_APP_NOTIFICATIONS_ENABLED, false)
    
    fun setPhoneNumber(phoneNumber: String) {
        sharedPreferences.edit()
            .putString(KEY_PHONE_NUMBER, phoneNumber)
            .apply()
    }
    
    fun getPhoneNumber(): String = sharedPreferences.getString(KEY_PHONE_NUMBER, "") ?: ""
    
    fun setTimeFormat24H(use24H: Boolean) {
        sharedPreferences.edit()
            .putBoolean(KEY_TIME_FORMAT_24H, use24H)
            .apply()
    }
    
    fun isTimeFormat24H(): Boolean = sharedPreferences.getBoolean(KEY_TIME_FORMAT_24H, false)
    
    fun setSkipLogin(skip: Boolean) {
        sharedPreferences.edit()
            .putBoolean(KEY_SKIP_LOGIN, skip)
            .apply()
    }
    
    fun shouldSkipLogin(): Boolean = sharedPreferences.getBoolean(KEY_SKIP_LOGIN, false)
    
    // Utility method to check if phone number is saved
    fun hasPhoneNumber(): Boolean = getPhoneNumber().isNotBlank()

    // Reminder setup prompt state
    fun setReminderSetupShown(shown: Boolean) {
        sharedPreferences.edit()
            .putBoolean(KEY_REMINDER_SETUP_SHOWN, shown)
            .apply()
    }
    
    fun hasReminderSetupShown(): Boolean = sharedPreferences.getBoolean(KEY_REMINDER_SETUP_SHOWN, false)
}
