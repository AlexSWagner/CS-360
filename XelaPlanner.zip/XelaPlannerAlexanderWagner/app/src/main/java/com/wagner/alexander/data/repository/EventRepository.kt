package com.wagner.alexander.data.repository

import android.content.Context
import com.wagner.alexander.data.database.XelaPlannerDatabase
import com.wagner.alexander.data.model.Event
import kotlinx.coroutines.flow.Flow
import java.time.LocalDateTime

/**
 * Repository for managing event-related operations
 * Coordinates between database and business logic for events
 */
class EventRepository(context: Context) {
    
    private val database = XelaPlannerDatabase.getDatabase(context)
    private val eventDao = database.eventDao()
    
    /**
     * Gets all events for a user (including guest events if userId is 0)
     * Returns a Flow for real-time updates
     */
    fun getEventsForUser(userId: Long): Flow<List<Event>> {
        return if (userId == 0L) {
            // Guest user - only show guest events
            eventDao.getGuestEvents()
        } else {
            // Logged-in user - show user events + guest events
            eventDao.getEventsForUser(userId)
        }
    }
    
    /**
     * Gets events for a specific date
     */
    suspend fun getEventsForDate(userId: Long, date: LocalDateTime): List<Event> {
        return eventDao.getEventsForDate(userId, date)
    }
    
    /**
     * Gets events within a date range
     */
    suspend fun getEventsInRange(
        userId: Long, 
        startDate: LocalDateTime, 
        endDate: LocalDateTime
    ): List<Event> {
        return eventDao.getEventsInRange(userId, startDate, endDate)
    }
    
    /**
     * Gets a specific event by ID
     */
    suspend fun getEventById(eventId: Long): Event? {
        return eventDao.getEventById(eventId)
    }
    
    /**
     * Creates a new event in the database
     * Returns the created event with its assigned ID
     * 
     * @param event The event to create (ID will be auto-generated)
     * @return Event object with assigned database ID
     * @throws Exception if database operation fails
     */
    suspend fun createEvent(event: Event): Event {
        return try {
            val eventId = eventDao.insertEvent(event)
            event.copy(id = eventId)
        } catch (e: Exception) {
            // Re-throw with context for caller to handle
            throw Exception("Failed to create event: ${e.message}", e)
        }
    }
    
    /**
     * Updates an existing event in the database
     * 
     * @param event The event to update (must have valid ID)
     * @throws Exception if database operation fails
     */
    suspend fun updateEvent(event: Event) {
        try {
            eventDao.updateEvent(event)
        } catch (e: Exception) {
            throw Exception("Failed to update event: ${e.message}", e)
        }
    }
    
    /**
     * Deletes an event from the database
     * 
     * @param event The event to delete
     * @throws Exception if database operation fails
     */
    suspend fun deleteEvent(event: Event) {
        try {
            eventDao.deleteEvent(event)
        } catch (e: Exception) {
            throw Exception("Failed to delete event: ${e.message}", e)
        }
    }
    
    /**
     * Deletes an event by its ID
     * 
     * @param eventId The ID of the event to delete
     * @throws Exception if database operation fails
     */
    suspend fun deleteEventById(eventId: Long) {
        try {
            eventDao.deleteEventById(eventId)
        } catch (e: Exception) {
            throw Exception("Failed to delete event with ID $eventId: ${e.message}", e)
        }
    }
    
    /**
     * Deletes all events for a specific user
     * Useful when deleting a user account
     */
    suspend fun deleteEventsForUser(userId: Long) {
        eventDao.deleteEventsForUser(userId)
    }
    
    /**
     * Validates event data before saving to ensure data integrity
     * Returns null if valid, descriptive error message if invalid
     * 
     * @param event The event to validate
     * @return null if valid, error message string if validation fails
     */
    fun validateEvent(event: Event): String? {
        return when {
            event.title.isBlank() -> "Event title cannot be empty"
            event.title.length > 100 -> "Event title is too long (max 100 characters)"
            event.description.length > 500 -> "Event description is too long (max 500 characters)"
            event.eventDate.isBefore(LocalDateTime.now().minusMinutes(1)) -> "Event cannot be scheduled in the past"
            else -> null
        }
    }
}
