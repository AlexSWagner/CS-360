package com.wagner.alexander.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.wagner.alexander.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    onLogout: () -> Unit,
    viewModel: SettingsViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    
    // SMS Permission launcher
    val smsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.handleSmsPermissionResult(isGranted)
    }
    
    // App Notification Permission launcher
    val appNotificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            // Permission granted - enable app notifications
            viewModel.onAppNotificationToggleClick(true, context)
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Account Section
            if (state.isLoggedIn) {
                SettingsSection(title = "Account") {
                    SettingsItem(
                        title = "Username",
                        subtitle = state.username,
                        icon = Icons.Default.Settings
                    )
                    
                    Button(
                        onClick = {
                            viewModel.onLogout()
                            onLogout()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Text("Logout")
                    }
                }
            } else {
                SettingsSection(title = "Account") {
                    Text(
                        text = "You are using the app as a guest. Some features may be limited.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = onLogout, // Navigate directly to Login screen
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("Return to Login")
                    }
                }
            }
            
            // Notifications Section
            SettingsSection(title = "Notifications") {
                SwitchSettingsItem(
                    title = "Enable App Notifications",
                    subtitle = if (state.appNotificationsEnabled) "Push notifications enabled" else "Push notifications disabled",
                    checked = state.appNotificationsEnabled,
                    enabled = true, // Always enabled, permission handled internally
                    onCheckedChange = { enabled ->
                        if (enabled && !viewModel.checkAppNotificationPermission(context)) {
                            // Request permission
                            appNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            viewModel.onAppNotificationToggleClick(enabled, context)
                        }
                    }
                )
                
                SwitchSettingsItem(
                    title = "Enable SMS Reminders",
                    subtitle = if (state.smsEnabled) "Text message reminders enabled" else "Text message reminders disabled",
                    checked = state.smsEnabled,
                    enabled = true, // Always enabled, permission handled internally
                    onCheckedChange = { enabled ->
                        if (enabled && !viewModel.checkSmsPermission(context)) {
                            // Request permission
                            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
                        } else {
                            viewModel.onSmsToggleClick(enabled, context)
                        }
                    }
                )
                
                SettingsItem(
                    title = "Phone Number",
                    subtitle = viewModel.getFormattedPhoneNumber(),
                    icon = Icons.Default.Phone,
                    onClick = {
                        // Show phone number dialog
                        viewModel.onPhoneNumberSubmitted("")
                    }
                )
                
                // Permission status cards
                if (!viewModel.checkAppNotificationPermission(context)) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Text(
                            text = "Notification permission is required for app notifications. Tap 'Enable App Notifications' to grant permission.",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
                
                if (!viewModel.checkSmsPermission(context)) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Text(
                            text = "SMS permission is required for text reminders. Tap 'Enable SMS Reminders' to grant permission.",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
            
            // Preferences Section
            SettingsSection(title = "Preferences") {
                SwitchSettingsItem(
                    title = "Time Format",
                    subtitle = if (state.timeFormat24H) "24-hour format" else "12-hour format",
                    checked = state.timeFormat24H,
                    onCheckedChange = viewModel::onTimeFormatToggle
                )
            }
            
            // Messages
            state.successMessage?.let { message ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            
            state.errorMessage?.let { message ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        }
    }
    
    // Phone Number Dialog
    if (state.showPhoneNumberDialog) {
        PhoneNumberDialog(
            onSave = viewModel::onPhoneNumberSubmitted,
            onDismiss = viewModel::onDismissPhoneNumberDialog
        )
    }
    
    // Permission Explanation Dialog
    if (state.showPermissionExplanationDialog) {
        PermissionExplanationDialog(
            onGrantPermission = {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
                viewModel.onDismissPermissionDialog()
            },
            onGoToSettings = {
                viewModel.openAppSettings(context)
            },
            onDismiss = viewModel::onDismissPermissionDialog
        )
    }
    
    // App Notification Permission Explanation Dialog
    if (state.showAppNotificationPermissionDialog) {
        AppNotificationPermissionExplanationDialog(
            onGrantPermission = {
                appNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                viewModel.onDismissAppNotificationPermissionDialog()
            },
            onGoToSettings = {
                viewModel.openAppSettings(context)
            },
            onDismiss = viewModel::onDismissAppNotificationPermissionDialog
        )
    }
}

@Composable
private fun SettingsSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        Card(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                content()
            }
        }
    }
}

@Composable
private fun SettingsItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onClick: (() -> Unit)? = null
) {
    val modifier = if (onClick != null) {
        Modifier.fillMaxWidth()
    } else {
        Modifier.fillMaxWidth()
    }
    
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon?.let {
            Icon(
                imageVector = it,
                contentDescription = null,
                modifier = Modifier.padding(end = 16.dp)
            )
        }
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SwitchSettingsItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled
        )
    }
}

@Composable
private fun PhoneNumberDialog(
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var phoneNumber by remember { mutableStateOf("") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enter Phone Number") },
        text = {
            Column {
                Text("Please enter your phone number for SMS notifications.")
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Standard messaging rates may apply.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it },
                    label = { Text("Phone Number") },
                    placeholder = { Text("+1 (555) 123-4567") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(phoneNumber) },
                enabled = phoneNumber.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun PermissionExplanationDialog(
    onGrantPermission: () -> Unit,
    onGoToSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("SMS Permission Required") },
        text = {
            Text("To enable SMS reminders, XelaPlanner needs permission to send text messages. This allows the app to notify you about upcoming events.")
        },
        confirmButton = {
            Button(onClick = onGrantPermission) {
                Text("Grant Permission")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun AppNotificationPermissionExplanationDialog(
    onGrantPermission: () -> Unit,
    onGoToSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Notification Permission Required") },
        text = {
            Text("To enable app notifications, XelaPlanner needs permission to send push notifications. This allows the app to remind you about upcoming events directly on your device.")
        },
        confirmButton = {
            Button(onClick = onGrantPermission) {
                Text("Grant Permission")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
