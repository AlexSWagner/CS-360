package com.wagner.alexander.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.wagner.alexander.ui.components.AgendaView
import com.wagner.alexander.ui.components.CalendarGrid
import com.wagner.alexander.ui.components.EventBottomSheet
import com.wagner.alexander.viewmodel.DashboardViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onNavigateToSettings: () -> Unit,
    viewModel: DashboardViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    
    // SMS Permission launcher
    val smsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            // Permission granted - trigger phone number setup flow
            viewModel.onSmsPermissionGranted()
        }
    }
    
    // App Notification Permission launcher
    val appNotificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.onAppNotificationPermissionResult(isGranted)
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = if (viewModel.isLoggedIn()) "XelaPlanner" else "XelaPlanner (Guest)",
                        style = MaterialTheme.typography.headlineSmall
                    )
                },
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            )
        },
        // FloatingActionButton removed as per redesign requirements
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Calendar Grid (Top Section)
            CalendarGrid(
                selectedDate = state.selectedDate,
                eventsMap = state.events.groupBy { it.eventDate.toLocalDate() },
                onDateSelected = viewModel::onDateSelected,
                onAddEventForDate = viewModel::onAddEventForDate
            )
            
            // Agenda View (Bottom Section) - Updated with new parameters
            AgendaView(
                events = state.events,
                upcomingEvents = state.upcomingEvents,
                pastEvents = state.pastEvents,
                selectedDate = state.selectedDate,
                onEditEvent = viewModel::onEditEvent,
                onDeleteEvent = viewModel::onDeleteEvent,
                onLongPressDelete = viewModel::onLongPressDelete,
                onClearDateFilter = viewModel::onClearDateFilter,
                onAddEventClick = viewModel::onAddEventClick,
                modifier = Modifier.weight(1f)
            )
        }
        
        // Add/Edit Event Bottom Sheet
        if (state.showAddEventSheet) {
            EventBottomSheet(
                event = state.eventToEdit,
                preselectedDate = state.preselectedDate,
                onDismiss = viewModel::onDismissBottomSheet,
                onSave = viewModel::onSaveEvent,
                onDelete = viewModel::onDeleteEvent
            )
        }
        
        // Combined Reminder Setup Dialog (first event)
        if (state.showReminderSetupDialog) {
            ReminderSetupDialog(
                onContinue = { enablePush, enableSms ->
                    if (enablePush && enableSms) {
                        // Queue SMS until after push permission result
                        viewModel.markPendingSmsAfterPush()
                    }

                    if (enablePush) {
                        if (!viewModel.checkAppNotificationPermission(context)) {
                            appNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            viewModel.onAppNotificationPermissionGranted()
                        }
                    }

                    if (!enablePush && enableSms) {
                        // If push is not requested, start SMS flow immediately
                        viewModel.startSmsSetupFlow()
                    }

                    viewModel.onReminderSetupClose()
                },
                onDismiss = {
                    viewModel.onReminderSetupClose()
                }
            )
        }
        
        // SMS Permission flow: directly request permission without redundant dialog
        if (state.showSmsPermissionDialog) {
            if (!viewModel.checkSmsPermission(context)) {
                LaunchedEffect(Unit) {
                    smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
                }
            } else {
                viewModel.onSmsPermissionDialogDismiss()
            }
        }
        
        // Phone Number Dialog
        if (state.showPhoneNumberDialog) {
            PhoneNumberDialog(
                onSave = viewModel::onPhoneNumberSubmitted,
                onDismiss = viewModel::onPhoneNumberDialogDismiss
            )
        }
        
        // Phone Number Saved Dialog
        if (state.showPhoneNumberSavedDialog) {
            PhoneNumberSavedDialog(
                onDismiss = viewModel::onPhoneNumberSavedDialogDismiss
            )
        }
        
        // App Notification Permission Dialog
        if (state.showAppNotificationPermissionDialog && !viewModel.checkAppNotificationPermission(context)) {
            AppNotificationPermissionDialog(
                onAgree = {
                    appNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    viewModel.onAppNotificationPermissionDialogDismiss()
                },
                onDismiss = viewModel::onAppNotificationPermissionDialogDismiss
            )
        } else if (state.showAppNotificationPermissionDialog && viewModel.checkAppNotificationPermission(context)) {
            // Permission already granted, dismiss dialog immediately
            viewModel.onAppNotificationPermissionDialogDismiss()
        }
        
        // Long Press Delete Confirmation Dialog
        if (state.showDeleteConfirmationDialog) {
            state.eventToDelete?.let { eventToDelete ->
                AlertDialog(
                    onDismissRequest = viewModel::onDismissDeleteDialog,
                    title = { Text("Delete Event") },
                    text = { Text("Are you sure you want to delete \"${eventToDelete.title}\"?") },
                    confirmButton = {
                        TextButton(
                            onClick = viewModel::onConfirmDelete
                        ) {
                            Text("Delete", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = viewModel::onDismissDeleteDialog) {
                            Text("Cancel")
                        }
                    }
                )
            }
        }
        
        // Success/Error Messages
        state.successMessage?.let { message ->
            LaunchedEffect(message) {
                // In a real app, you might use a SnackbarHost here
                // For now, the message will be cleared automatically by the ViewModel
            }
        }
        
        state.errorMessage?.let { message ->
            LaunchedEffect(message) {
                // In a real app, you might use a SnackbarHost here
                // For now, the message will be cleared automatically by the ViewModel
            }
        }
    }
}

@Composable
private fun SmsPermissionDialog(
    onAgree: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("SMS Event Reminders")
        },
        text = {
            Column {
                Text(
                    text = "XelaPlanner can send you SMS text message reminders for your events so you never miss important appointments.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "SMS permission is required to send these reminders to your phone.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "You can always change this setting later in the app settings.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(onClick = onAgree) {
                Text("Enable SMS Reminders")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Maybe Later")
            }
        }
    )
}

@Composable
private fun PhoneNumberDialog(
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var phoneNumber by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val viewModel: DashboardViewModel = viewModel()
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enter Phone Number") },
        text = {
            Column {
                Text("Please enter your phone number for SMS notifications.")
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Standard messaging rates may apply.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = {
                        phoneNumber = it
                        errorText = null
                    },
                    label = { Text("Phone Number") },
                    placeholder = { Text("+1 (555) 123-4567") },
                    singleLine = true,
                    isError = errorText != null,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    )
                )
                errorText?.let { msg ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    // Validate before saving
                    val repo = com.wagner.alexander.data.repository.SettingsRepository(context)
                    val validationError = repo.validatePhoneNumber(phoneNumber)
                    if (validationError != null) {
                        errorText = validationError
                    } else {
                        onSave(phoneNumber)
                    }
                },
                enabled = phoneNumber.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun PhoneNumberSavedDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Phone Number Saved") },
        text = {
            Text("In a production app, we would now send a confirmation code to this number to verify ownership. For this assignment, we will skip this step and assume the number is verified.")
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("OK")
            }
        }
    )
}

@Composable
private fun AppNotificationPermissionDialog(
    onAgree: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("App Notifications")
        },
        text = {
            Column {
                Text(
                    text = "XelaPlanner can send you push notifications to remind you about upcoming events directly on your device.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Notification permission is required to send these reminders.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "You can always change this setting later in the app settings.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(onClick = onAgree) {
                Text("Enable Notifications")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Maybe Later")
            }
        }
    )
}

@Composable
private fun ReminderSetupDialog(
    onContinue: (Boolean, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var pushEnabled by remember { mutableStateOf(true) }
    var smsEnabled by remember { mutableStateOf(false) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enable Event Reminders") },
        text = {
            Column {
                Text(
                    text = "Get reminded about your events with push notifications and optional SMS alerts.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "You can change these settings anytime in Settings.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = pushEnabled, onCheckedChange = { pushEnabled = it })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Push Notifications")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = smsEnabled, onCheckedChange = { smsEnabled = it })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("SMS Alerts")
                }
            }
        },
        confirmButton = {
            Button(onClick = { onContinue(pushEnabled, smsEnabled) }) {
                Text("Continue")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Maybe Later") }
        }
    )
}