package com.wagner.alexander.data.database

import android.content.Context
import androidx.room.*
import com.wagner.alexander.data.model.Event
import com.wagner.alexander.data.model.User

/**
 * Room database for XelaPlanner app
 * Stores user accounts and events with proper relationships
 */
@Database(
    entities = [User::class, Event::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class XelaPlannerDatabase : RoomDatabase() {
    
    abstract fun userDao(): UserDao
    abstract fun eventDao(): EventDao
    
    companion object {
        @Volatile
        private var INSTANCE: XelaPlannerDatabase? = null
        
        fun getDatabase(context: Context): XelaPlannerDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    XelaPlannerDatabase::class.java,
                    "xela_planner_database"
                )
                .fallbackToDestructiveMigration() // For development only
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
