package com.wagner.alexander.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.wagner.alexander.data.model.EventCategory

// Standard Material 3 color schemes
private val DarkColorScheme = darkColorScheme(
    primary = Purple80,
    secondary = PurpleGrey80,
    tertiary = Pink80
)

private val LightColorScheme = lightColorScheme(
    primary = Purple40,
    secondary = PurpleGrey40,
    tertiary = Pink40
)

// Define a data class for our custom category colors
@Immutable
data class CategoryColorScheme(
    val work: Color = Color.Unspecified,
    val health: Color = Color.Unspecified,
    val study: Color = Color.Unspecified,
    val family: Color = Color.Unspecified,
    val personal: Color = Color.Unspecified
)

// Create a CompositionLocal to provide the custom colors
private val LocalCategoryColorScheme = staticCompositionLocalOf { CategoryColorScheme() }

// Create an extension on MaterialTheme to easily access the custom colors
val MaterialTheme.categoryColorScheme: CategoryColorScheme
    @Composable
    get() = LocalCategoryColorScheme.current

// Create a single, reusable function to get the correct color
@Composable
fun getCategoryColor(category: EventCategory): Color {
    return when (category) {
        EventCategory.WORK -> MaterialTheme.categoryColorScheme.work
        EventCategory.HEALTH -> MaterialTheme.categoryColorScheme.health
        EventCategory.STUDY -> MaterialTheme.categoryColorScheme.study
        EventCategory.FAMILY -> MaterialTheme.categoryColorScheme.family
        EventCategory.PERSONAL -> MaterialTheme.categoryColorScheme.personal
    }
}

@Composable
fun XelaPlannerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    // Define the actual colors for custom scheme
    val categoryColors = CategoryColorScheme(
        work = CategoryWork,
        health = CategoryHealth,
        study = CategoryStudy,
        family = CategoryFamily,
        personal = CategoryPersonal
    )

    // Provide the custom color scheme to the rest of the app
    CompositionLocalProvider(LocalCategoryColorScheme provides categoryColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
