package com.wagner.alexander.notifications

import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.wagner.alexander.data.repository.EventRepository
import com.wagner.alexander.data.repository.SettingsRepository
import kotlinx.coroutines.runBlocking

/**
 * WorkManager worker for sending SMS notifications
 * Handles the actual SMS sending for event reminders
 */
class SmsNotificationWorker(
    context: Context,
    workerParams: WorkerParameters
) : Worker(context, workerParams) {

    private val eventRepository = EventRepository(context)
    private val settingsRepository = SettingsRepository(context)

    companion object {
        const val KEY_EVENT_ID = "event_id"
        const val KEY_EVENT_TITLE = "event_title"
        const val KEY_EVENT_TIME = "event_time"
    }

    override fun doWork(): Result {
        return try {
            // Check if SMS is still enabled globally
            if (!settingsRepository.isSmsEnabled()) {
                return Result.success()
            }

            // Check if we have SMS permission
            if (!hasSmsPermission()) {
                return Result.failure()
            }

            // Get phone number
            val phoneNumber = settingsRepository.getPhoneNumber()
            if (phoneNumber.isBlank()) {
                return Result.failure()
            }

            // Get event details from input data
            val eventId = inputData.getLong(KEY_EVENT_ID, -1L)
            val eventTitle = inputData.getString(KEY_EVENT_TITLE) ?: "Event"
            val eventTime = inputData.getString(KEY_EVENT_TIME) ?: ""

            // Verify event still exists
            val event = runBlocking {
                eventRepository.getEventById(eventId)
            }

            if (event == null) {
                // Event was deleted, no need to send notification
                return Result.success()
            }

            // Send SMS
            sendSms(phoneNumber, eventTitle, eventTime)

            Result.success()
        } catch (e: Exception) {
            // Log error in production app
            Result.failure()
        }
    }

    private fun sendSms(phoneNumber: String, eventTitle: String, eventTime: String) {
        try {
            val smsManager = SmsManager.getDefault()
            val message = buildSmsMessage(eventTitle, eventTime)
            
            // Send the SMS
            smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                null,
                null
            )
        } catch (e: Exception) {
            // Handle SMS sending errors
            throw e
        }
    }

    private fun buildSmsMessage(eventTitle: String, eventTime: String): String {
        return "XelaPlanner Reminder: '$eventTitle' is starting now ($eventTime). Don't forget!"
    }

    private fun hasSmsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            applicationContext,
            android.Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }
}
