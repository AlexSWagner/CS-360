package com.wagner.alexander.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.wagner.alexander.data.model.Event
import java.time.LocalDate
import java.time.LocalDateTime

@Composable
fun AgendaView(
    events: List<Event>,
    upcomingEvents: List<Event>,
    pastEvents: List<Event>,
    selectedDate: LocalDate?,
    onEditEvent: (Event) -> Unit,
    onDeleteEvent: (Long) -> Unit,
    onLongPressDelete: (Event) -> Unit,
    onClearDateFilter: () -> Unit,
    onAddEventClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(horizontal = 16.dp).fillMaxHeight()) {
        // Header: left-aligned "Agenda" and right-aligned "+ Add Event"
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selectedDate != null) {
                IconButton(onClick = onClearDateFilter) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Clear filter"
                    )
                }
            }
            Text(
                text = "Agenda",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Start
            )
            Button(
                onClick = onAddEventClick,
                modifier = Modifier
                    .wrapContentWidth()
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Event")
            }
        }

        // Display events based on filter or show upcoming/past events
        val eventsToShow = if (selectedDate != null) {
            events.filter { it.eventDate.toLocalDate() == selectedDate }
        } else {
            upcomingEvents + pastEvents
        }
        
        if (eventsToShow.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "No events scheduled",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Long-press a day or tap 'Add Event' to create one",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                if (selectedDate == null) {
                    // Unified list: upcoming (chronological), then past (reverse-chronological)
                    items(upcomingEvents, key = { it.id }) { event ->
                        EventCard(
                            event = event,
                            isPastEvent = false,
                            onTap = { onEditEvent(event) },
                            onLongPress = { onLongPressDelete(event) }
                        )
                    }
                    items(pastEvents, key = { it.id }) { event ->
                        EventCard(
                            event = event,
                            isPastEvent = true,
                            onTap = { onEditEvent(event) },
                            onLongPress = { onLongPressDelete(event) }
                        )
                    }
                } else {
                    // Show filtered events for selected date
                    items(eventsToShow, key = { it.id }) { event ->
                        val isPast = event.eventDate.isBefore(LocalDateTime.now())
                        EventCard(
                            event = event,
                            isPastEvent = isPast,
                            onTap = { onEditEvent(event) },
                            onLongPress = { onLongPressDelete(event) }
                        )
                    }
                }
            }
        }
    }
}
