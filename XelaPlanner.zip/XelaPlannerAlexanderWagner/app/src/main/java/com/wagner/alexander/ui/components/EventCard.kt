package com.wagner.alexander.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.wagner.alexander.data.model.Event
import com.wagner.alexander.data.model.EventCategory
import com.wagner.alexander.data.repository.SettingsRepository
import com.wagner.alexander.ui.theme.getCategoryColor
import com.wagner.alexander.utils.TimeFormatUtils

/**
 * A redesigned event card with tap-to-edit and long-press-to-delete gestures.
 * Past events are visually de-emphasized with reduced opacity.
 *
 * @param event The event data to display.
 * @param isPastEvent Whether this event is in the past (for visual de-emphasis).
 * @param onTap Callback triggered when the card is tapped (opens edit sheet).
 * @param onLongPress Callback triggered when the card is long-pressed (delete confirmation).
 * @param modifier The modifier to be applied to the card.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun EventCard(
    event: Event,
    isPastEvent: Boolean = false,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settingsRepository = remember { SettingsRepository(context) }
    val use24HourFormat = settingsRepository.isTimeFormat24H()
    
    // Apply opacity for past events
    val cardAlpha = if (isPastEvent) 0.6f else 1f

    Card(
        modifier = modifier
            .fillMaxWidth()
            .alpha(cardAlpha)
            .combinedClickable(
                onClick = onTap,
                onLongClick = onLongPress
            )
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                shape = MaterialTheme.shapes.large
            ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        colors = CardDefaults.cardColors()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Left column: Title, Description, Timestamp (verbose)
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    // Strikethrough only for past events
                    textDecoration = if (isPastEvent) TextDecoration.LineThrough else null
                )
                if (event.description.isNotEmpty()) {
                    Text(
                        text = event.description,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = TimeFormatUtils.formatVerboseDateTime(event.eventDate, use24HourFormat),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Right column: Category label at top-right
            Box(
                modifier = Modifier.wrapContentWidth(),
                contentAlignment = Alignment.TopEnd
            ) {
                Surface(
                    shape = CircleShape,
                    color = getCategoryColor(event.category),
                    contentColor = Color.White,
                ) {
                    Text(
                        text = event.category.name,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
