package com.wagner.alexander.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.wagner.alexander.data.model.Event
import com.wagner.alexander.ui.theme.getCategoryColor
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable
fun CalendarGrid(
    selectedDate: LocalDate?,
    eventsMap: Map<LocalDate, List<Event>>,
    onDateSelected: (LocalDate) -> Unit,
    onAddEventForDate: (LocalDate) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentMonth = remember { mutableStateOf(YearMonth.now()) }

    Column(modifier = modifier.padding(8.dp)) {
        // Month header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = {
                currentMonth.value = currentMonth.value.minusMonths(1)
            }) {
                Text("‹")
            }

            Text(
                text = currentMonth.value.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            TextButton(onClick = {
                currentMonth.value = currentMonth.value.plusMonths(1)
            }) {
                Text("›")
            }
        }

        // Day headers
        Row(modifier = Modifier.fillMaxWidth()) {
            val dayHeaders = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
            dayHeaders.forEach { day ->
                Text(
                    text = day,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Calendar grid
        CalendarDays(
            yearMonth = currentMonth.value,
            selectedDate = selectedDate,
            eventsMap = eventsMap,
            onDateSelected = onDateSelected,
            onAddEventForDate = onAddEventForDate
        )
    }
}

@Composable
private fun CalendarDays(
    yearMonth: YearMonth,
    selectedDate: LocalDate?,
    eventsMap: Map<LocalDate, List<Event>>,
    onDateSelected: (LocalDate) -> Unit,
    onAddEventForDate: (LocalDate) -> Unit
) {
    val firstDayOfMonth = yearMonth.atDay(1)
    val lastDayOfMonth = yearMonth.atEndOfMonth()
    val firstDayOfWeek = firstDayOfMonth.dayOfWeek.value % 7
    val daysInMonth = yearMonth.lengthOfMonth()

    // Create a list of dates including empty cells for proper alignment
    val calendarDates = mutableListOf<LocalDate?>()

    // Add empty cells for days before the first day of the month
    repeat(firstDayOfWeek) {
        calendarDates.add(null)
    }

    // Add all days of the month
    for (day in 1..daysInMonth) {
        calendarDates.add(yearMonth.atDay(day))
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(7),
        contentPadding = PaddingValues(4.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        items(calendarDates) { date ->
            CalendarDay(
                date = date,
                isSelected = date == selectedDate,
                eventsForDate = date?.let { eventsMap[it] } ?: emptyList(),
                onDateSelected = onDateSelected,
                onAddEventForDate = onAddEventForDate
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CalendarDay(
    date: LocalDate?,
    isSelected: Boolean,
    eventsForDate: List<Event>,
    onDateSelected: (LocalDate) -> Unit,
    onAddEventForDate: (LocalDate) -> Unit
) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
            .then(
                if (date != null) {
                    Modifier.combinedClickable(
                        onClick = { onDateSelected(date) },
                        onLongClick = { onAddEventForDate(date) }
                    )
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        if (date != null) {
            val backgroundColor = when {
                isSelected -> MaterialTheme.colorScheme.primary
                date == LocalDate.now() -> MaterialTheme.colorScheme.primaryContainer
                else -> Color.Transparent
            }

            val textColor = when {
                isSelected -> MaterialTheme.colorScheme.onPrimary
                date == LocalDate.now() -> MaterialTheme.colorScheme.onPrimaryContainer
                else -> MaterialTheme.colorScheme.onSurface
            }

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(backgroundColor, CircleShape)
                    .clip(CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = date.dayOfMonth.toString(),
                        style = MaterialTheme.typography.bodySmall,
                        color = textColor,
                        fontWeight = if (isSelected || date == LocalDate.now()) FontWeight.Bold else FontWeight.Normal
                    )

                    // Event indicators
                    if (eventsForDate.isNotEmpty()) {
                        EventIndicators(
                            events = eventsForDate,
                            isSelected = isSelected
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EventIndicators(
    events: List<Event>,
    isSelected: Boolean
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(1.dp),
        modifier = Modifier.padding(top = 2.dp)
    ) {
        // Show up to 8 event markers, one per event
        val visibleEvents = events.take(8)

        visibleEvents.forEach { event ->
            Box(
                modifier = Modifier
                    .size(6.dp) // Increased from 3.dp to 6.dp (2x larger)
                    .background(
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            // Now using the centralized theme function
                            getCategoryColor(event.category)
                        },
                        shape = CircleShape
                    )
            )
        }
    }
}
