package com.wagner.alexander.data.state

import com.wagner.alexander.data.model.Event
import java.time.LocalDate

data class DashboardState(
    val events: List<Event> = emptyList(),
    val upcomingEvents: List<Event> = emptyList(),
    val pastEvents: List<Event> = emptyList(),
    val selectedDate: LocalDate? = null,
    val isLoading: Boolean = false,
    val showAddEventSheet: Boolean = false,
    val eventToEdit: Event? = null,
    val preselectedDate: LocalDate? = null,
    val showSmsPermissionDialog: Boolean = false,
    val showAppNotificationPermissionDialog: Boolean = false,
    val eventForPermissionCheck: Event? = null,
    val showPhoneNumberDialog: Boolean = false,
    val showPhoneNumberSavedDialog: Boolean = false,
    val showReminderSetupDialog: Boolean = false,
    val pendingEnableSmsAfterPush: Boolean = false,
    val showDeleteConfirmationDialog: Boolean = false,
    val eventToDelete: Event? = null,
    val errorMessage: String? = null,
    val successMessage: String? = null
)